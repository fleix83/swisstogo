<?php
l::set( array(
	'seo.title' => 'SEO Titel',
	'seo.description' => 'SEO Meta-Beschreibung',
	'fallback' => 'Zurückfallen',
	'values' => 'Werte',
	'plugin.required' => 'Seo Plugin ist erforderlich!',
	'description.fallback' => 'Dies ist eine Meta-Beschreibung, die in den Suchergebnissen erscheint. Leer lassen, damit die Suchmaschinen relevanten Text aus dem Seiteninhalt abrufen können.'
));
