<?php
l::set( array(
	'seo.title' => 'SEO title',
	'seo.description' => 'SEO meta description',
	'fallback' => 'Fallback',
	'values' => 'Values',
	'plugin.required' => 'SEO plugin is required!',
	'description.fallback' => 'This is a meta description that appears in the search results. Leave blank to let the search engines retrieve relevant text from the page content.'
));
