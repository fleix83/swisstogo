<?php
l::set( array(
	'seo.title' => 'SEO titel',
	'seo.description' => 'SEO metabeskrivning',
	'fallback' => 'Standardvärde',
	'values' => 'Värden',
	'plugin.required' => 'SEO plugin krävs!',
	'description.empty' => 'Detta är en metabeskrivning som visas i sökresultaten. Lämna tomt för att låta sökmotorerna hämta relevant text från sidans innehåll.'
));
